#!/usr/bin/env python3
"""
test.py - Quick model evaluation

Usage:
    python test.py --model polynomial
    python test.py --model ar
"""
import argparse
from pathlib import Path

import torch
import sympy

from config import get_device, CONFIGS, DOMAINS
from vocab import Vocabulary
from model import SymbolicTransformer
from generators import get_generator, compute_algebraic_features, compute_timeseries_features, compute_physics_features


# ============================================================================
# Expression Cleanup (post-processing)
# ============================================================================

COMMON_FRACTIONS = {
    0.5: sympy.Rational(1, 2),
    0.25: sympy.Rational(1, 4),
    0.75: sympy.Rational(3, 4),
    0.333: sympy.Rational(1, 3),
    0.667: sympy.Rational(2, 3),
    0.2: sympy.Rational(1, 5),
    0.4: sympy.Rational(2, 5),
    0.6: sympy.Rational(3, 5),
    0.8: sympy.Rational(4, 5),
    1.5: sympy.Rational(3, 2),
}


def snap_coefficient(coef: float, thresh: float = 0.05):
    """Snap to integer or common fraction if close."""
    rounded = round(coef)
    if abs(coef - rounded) < thresh:
        return int(rounded)
    for val, frac in COMMON_FRACTIONS.items():
        if abs(coef - val) < thresh:
            return frac
        if abs(coef + val) < thresh:
            return -frac
    return coef


def clean_expression(expr, prune_thresh: float = 0.1, snap_thresh: float = 0.05):
    """Prune tiny terms and snap coefficients."""
    if expr.is_Atom:
        if expr.is_Number:
            return snap_coefficient(float(expr), snap_thresh)
        return expr
    
    try:
        expanded = sympy.expand(expr)
        terms = sympy.Add.make_args(expanded)
        
        # Find max coefficient for relative pruning
        max_coef = 0
        term_data = []
        for term in terms:
            coef, rest = term.as_coeff_Mul()
            coef_f = float(coef)
            term_data.append((coef_f, rest))
            max_coef = max(max_coef, abs(coef_f))
        
        effective_thresh = max(prune_thresh, 0.05 * max_coef)
        
        cleaned = []
        for coef_f, rest in term_data:
            if abs(coef_f) < effective_thresh:
                continue
            snapped = snap_coefficient(coef_f, snap_thresh)
            if snapped == 0:
                continue
            if rest == 1:
                cleaned.append(sympy.sympify(snapped))
            else:
                cleaned.append(snapped * rest)
        
        return sympy.Add(*cleaned) if cleaned else sympy.Integer(0)
    except:
        return expr


def tokens_to_string(tokens: list[str]) -> str:
    """Convert token list to expression string."""
    parts = []
    i = 0
    while i < len(tokens):
        t = tokens[i]
        if t == "CONST":
            i += 1
            val = ""
            while i < len(tokens) and (tokens[i].isdigit() or tokens[i] == "POINT"):
                val += "." if tokens[i] == "POINT" else tokens[i]
                i += 1
            parts.append(val if val else "C")
            continue
        
        mapping = {"MUL": "*", "DIV": "/", "ADD": "+", "SUB": "-", "POW": "**", "NEG": "-"}
        if t in mapping:
            parts.append(mapping[t])
        elif t.startswith("INT_"):
            parts.append(t.split("_")[1])
        elif t in ("SIN", "COS", "TAN", "EXP", "LN", "LOG", "SQRT"):
            parts.append(t.lower())
        elif t == "HALF":
            parts.append("0.5")
        else:
            parts.append(t)
        i += 1
    
    return " ".join(parts)


def cleanup_prediction(pred_str: str) -> str:
    """Apply expression cleanup to prediction string."""
    try:
        expr = sympy.sympify(pred_str)
        cleaned = clean_expression(expr)
        return str(cleaned)
    except:
        return pred_str


# ============================================================================
# Test Cases
# ============================================================================

TEST_CASES = {
    "polynomial": [
        {"name": "linear_simple", "subtype": "linear_positive", "threshold": 0.8},
        {"name": "quadratic_vertex", "subtype": "quadratic_up", "threshold": 0.8},
        {"name": "cubic", "subtype": "cubic", "threshold": 0.7},
    ],
    "ar": [
        {"name": "ar1_medium", "subtype": "ar1_medium", "threshold": 0.5},
        {"name": "ar1_high", "subtype": "ar1_high", "threshold": 0.5},
    ],
    "transcendental": [
        {"name": "exp_decay", "subtype": "exp_decay", "threshold": 0.5},
        {"name": "power_law", "subtype": "power_positive", "threshold": 0.5},
        {"name": "logarithmic", "subtype": "logarithmic", "threshold": 0.5},
    ],
    "physics_laws": [
        {"name": "newton_gravity", "subtype": "newton_gravity", "threshold": 0.5},
        {"name": "coulomb", "subtype": "coulomb", "threshold": 0.5},
        {"name": "kinetic_energy", "subtype": "kinetic_energy", "threshold": 0.5},
    ],
}


def get_feature_fn(model_type: str):
    """Get appropriate feature function for model type."""
    if model_type in ("polynomial", "transcendental"):
        return lambda data: compute_algebraic_features(data[:, 0], data[:, 1]) if data.ndim == 2 else compute_algebraic_features(np.arange(len(data)), data)
    elif model_type == "ar":
        return compute_timeseries_features
    elif model_type == "physics_laws":
        return compute_physics_features
    return lambda x: x


def test(args):
    import numpy as np
    
    device = get_device()
    
    if args.model not in CONFIGS:
        print(f"Unknown model: {args.model}")
        return
    
    cfg = CONFIGS[args.model]
    domain = DOMAINS[args.model]
    
    # Load model
    checkpoint_path = Path("checkpoints") / domain / args.model / "model_best.pt"
    if not checkpoint_path.exists():
        print(f"No checkpoint found at {checkpoint_path}")
        return
    
    vocab = Vocabulary.default()
    model = SymbolicTransformer(vocab_size=vocab.vocab_size, **cfg).to(device)
    
    ckpt = torch.load(checkpoint_path, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["model"])
    model.eval()
    
    print(f"Loaded: {checkpoint_path}", flush=True)
    
    # Get test cases
    test_cases = TEST_CASES.get(args.model, [])
    if not test_cases:
        print(f"No test cases for {args.model}")
        return
    
    generator = get_generator(args.model)
    
    print(f"\nRunning {len(test_cases)} tests for {args.model}...")
    print("=" * 70)
    
    passed = 0
    for tc in test_cases:
        # Generate sample
        features, truth_tokens, _ = generator.generate()
        
        # Predict
        feat_tensor = torch.tensor(features, dtype=torch.float32).to(device)
        with torch.no_grad():
            pred_ids = model.generate(feat_tensor, vocab)
        pred_tokens = vocab.decode(pred_ids)
        
        # Convert to strings
        truth_str = tokens_to_string(truth_tokens)
        pred_str = tokens_to_string(pred_tokens)
        
        # Cleanup
        if args.cleanup:
            pred_str = cleanup_prediction(pred_str)
            truth_str = cleanup_prediction(truth_str)
        
        # Simple match check (structural)
        match = pred_str.strip() == truth_str.strip()
        
        threshold = tc["threshold"]
        status = "PASS" if match else "FAIL"
        color = "\033[92m" if match else "\033[91m"
        
        if match:
            passed += 1
        
        print(f"{color}[{status}] {tc['name']}\033[0m")
        print(f"  Truth:     {truth_str}")
        print(f"  Predicted: {pred_str}")
        print("-" * 70)
    
    print(f"\nSummary: {passed}/{len(test_cases)} passed")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True)
    parser.add_argument("--cleanup", action="store_true", default=True, help="Apply coefficient cleanup")
    parser.add_argument("--no-cleanup", dest="cleanup", action="store_false")
    
    args = parser.parse_args()
    test(args)
