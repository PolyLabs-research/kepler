"""
config.py - Hardware detection and model configs (NVIDIA/CPU agnostic)
"""
import torch

def get_device() -> str:
    """Auto-detect best available device."""
    if torch.cuda.is_available():
        return "cuda"
    elif hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return "mps"  # Apple Silicon
    return "cpu"

def get_vram_gb() -> float:
    """Get available VRAM in GB (0 if CPU)."""
    if torch.cuda.is_available():
        return torch.cuda.get_device_properties(0).total_memory / 1e9
    return 0

def auto_batch_size(base: int = 1024) -> int:
    """Scale batch size to available VRAM."""
    vram = get_vram_gb()
    if vram >= 16:
        return base
    elif vram >= 8:
        return base // 2
    elif vram >= 4:
        return base // 4
    return 128  # CPU or very low VRAM

# Model configurations (same structure, smaller if needed)
CONFIGS = {
    "polynomial": {
        "feature_dim": 48,
        "d_model": 256,
        "nhead": 8,
        "num_encoder_layers": 4,
        "num_decoder_layers": 4,
        "dim_feedforward": 1024,
        "dropout": 0.1,
        "max_seq_len": 64,
    },
    "ar": {
        "feature_dim": 32,
        "d_model": 256,
        "nhead": 8,
        "num_encoder_layers": 4,
        "num_decoder_layers": 4,
        "dim_feedforward": 1024,
        "dropout": 0.1,
        "max_seq_len": 64,
    },
    "transcendental": {
        "feature_dim": 48,
        "d_model": 256,
        "nhead": 8,
        "num_encoder_layers": 4,
        "num_decoder_layers": 4,
        "dim_feedforward": 1024,
        "dropout": 0.1,
        "max_seq_len": 64,
    },
    "physics_laws": {
        "feature_dim": 64,
        "d_model": 256,
        "nhead": 8,
        "num_encoder_layers": 4,
        "num_decoder_layers": 4,
        "dim_feedforward": 1024,
        "dropout": 0.1,
        "max_seq_len": 64,
    },
}

TRAINING = {
    "learning_rate": 3e-4,
    "warmup_steps": 1000,
    "max_steps": 50000,
    "gradient_clip": 1.0,
    "log_interval": 100,
    "save_interval": 1000,
}

# Domain mapping
DOMAINS = {
    "polynomial": "algebraic",
    "transcendental": "algebraic",
    "ar": "timeseries",
    "physics_laws": "multivariate",
}
