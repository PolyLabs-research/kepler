#!/bin/bash
# Minimal setup for NVIDIA laptop

# Create virtual environment (optional but clean)
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install numpy scipy sympy pyyaml

# Verify CUDA
python3 -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}'); print(f'Device: {torch.cuda.get_device_name(0) if torch.cuda.is_available() else \"CPU\"}')"

echo "Setup complete. Run: python train.py --model polynomial"
