"""
generators.py - Minimal data generators for training
"""
import numpy as np
from abc import ABC, abstractmethod

# ============================================================================
# Feature Extraction
# ============================================================================

def compute_algebraic_features(x: np.ndarray, y: np.ndarray, dim: int = 48) -> np.ndarray:
    """Extract features from (x, y) curve data."""
    features = np.zeros(dim, dtype=np.float32)
    
    # Basic stats
    features[0] = np.mean(y)
    features[1] = np.std(y)
    features[2] = np.min(y)
    features[3] = np.max(y)
    features[4] = y[-1] - y[0]  # net change
    
    # Derivatives
    dy = np.gradient(y, x)
    features[5] = np.mean(dy)
    features[6] = np.std(dy)
    features[7] = np.mean(np.abs(dy))
    
    d2y = np.gradient(dy, x)
    features[8] = np.mean(d2y)
    features[9] = np.std(d2y)
    
    # Monotonicity
    features[10] = np.mean(dy > 0)  # fraction increasing
    features[11] = np.sum(np.diff(np.sign(dy)) != 0)  # sign changes
    
    # Curvature
    features[12] = np.mean(d2y > 0)  # fraction concave up
    features[13] = np.sum(np.diff(np.sign(d2y)) != 0)  # inflection points
    
    # Range ratios
    x_range = x[-1] - x[0]
    y_range = features[3] - features[2]
    features[14] = y_range / (x_range + 1e-8)
    
    # Polynomial fits
    for deg in range(1, 6):
        try:
            coeffs = np.polyfit(x, y, deg)
            residuals = y - np.polyval(coeffs, x)
            features[14 + deg] = np.std(residuals)
        except:
            features[14 + deg] = 1.0
    
    # Normalize
    features = np.nan_to_num(features, nan=0.0, posinf=1.0, neginf=-1.0)
    features = np.clip(features, -10, 10)
    
    return features


def compute_timeseries_features(y: np.ndarray, dim: int = 32) -> np.ndarray:
    """Extract features from 1D timeseries."""
    features = np.zeros(dim, dtype=np.float32)
    
    # Basic stats
    features[0] = np.mean(y)
    features[1] = np.std(y)
    features[2] = np.min(y)
    features[3] = np.max(y)
    
    # Autocorrelation
    y_centered = y - np.mean(y)
    var = np.var(y) + 1e-8
    for lag in range(1, min(11, len(y))):
        acf = np.mean(y_centered[lag:] * y_centered[:-lag]) / var
        features[3 + lag] = acf
    
    # Partial autocorrelation (simplified)
    features[14] = features[4]  # lag-1
    if abs(features[4]) < 1:
        features[15] = (features[5] - features[4]**2) / (1 - features[4]**2 + 1e-8)
    
    # Trend
    x = np.arange(len(y))
    slope, _ = np.polyfit(x, y, 1)
    features[16] = slope
    
    # Normalize
    features = np.nan_to_num(features, nan=0.0, posinf=1.0, neginf=-1.0)
    features = np.clip(features, -10, 10)
    
    return features


def compute_physics_features(data: dict, dim: int = 64) -> np.ndarray:
    """Extract features from multivariate physics data."""
    features = np.zeros(dim, dtype=np.float32)
    
    # Get all variables
    vars_list = list(data.keys())
    output_key = vars_list[-1]  # Last variable is typically output
    output = data[output_key]
    
    # Output stats
    features[0] = np.mean(output)
    features[1] = np.std(output)
    features[2] = np.min(output)
    features[3] = np.max(output)
    
    # Input-output relationships
    idx = 4
    for key in vars_list[:-1]:
        if idx >= dim - 4:
            break
        inp = data[key]
        # Correlation
        corr = np.corrcoef(inp, output)[0, 1]
        features[idx] = corr if not np.isnan(corr) else 0
        idx += 1
        # Log correlation (for power laws)
        try:
            log_corr = np.corrcoef(np.log(np.abs(inp) + 1e-8), np.log(np.abs(output) + 1e-8))[0, 1]
            features[idx] = log_corr if not np.isnan(log_corr) else 0
        except:
            features[idx] = 0
        idx += 1
    
    features = np.nan_to_num(features, nan=0.0, posinf=1.0, neginf=-1.0)
    features = np.clip(features, -10, 10)
    
    return features


# ============================================================================
# Base Generator
# ============================================================================

class BaseGenerator(ABC):
    SUBTYPES = {}
    WEIGHTS = {}
    
    def _sample_subtype(self) -> str:
        subtypes = list(self.SUBTYPES.keys())
        weights = [self.WEIGHTS.get(s, 1.0) for s in subtypes]
        weights = np.array(weights) / sum(weights)
        return np.random.choice(subtypes, p=weights)
    
    @abstractmethod
    def generate(self) -> tuple[np.ndarray, list[str], str]:
        """Return (features, tokens, subtype)"""
        pass


# ============================================================================
# Polynomial Generator
# ============================================================================

class PolynomialGenerator(BaseGenerator):
    SUBTYPES = {
        "linear_positive": {"degree": 1, "leading_sign": 1},
        "linear_negative": {"degree": 1, "leading_sign": -1},
        "quadratic_up": {"degree": 2, "leading_sign": 1},
        "quadratic_down": {"degree": 2, "leading_sign": -1},
        "cubic": {"degree": 3},
        "quartic": {"degree": 4},
    }
    WEIGHTS = {k: 1.0 for k in SUBTYPES}
    
    def __init__(self, n_points: int = 200, x_range: tuple = (-5, 5)):
        self.n_points = n_points
        self.x_range = x_range
    
    def generate(self) -> tuple[np.ndarray, list[str], str]:
        subtype = self._sample_subtype()
        config = self.SUBTYPES[subtype]
        degree = config["degree"]
        
        # Generate coefficients
        coeffs = np.random.uniform(-3, 3, size=degree + 1)
        if "leading_sign" in config:
            coeffs[-1] = abs(coeffs[-1]) * config["leading_sign"]
        
        # Generate data
        x = np.linspace(*self.x_range, self.n_points)
        y = np.polyval(coeffs[::-1], x)  # polyval expects highest degree first
        
        # Tokenize (simplified - just structure)
        tokens = self._coeffs_to_tokens(coeffs)
        
        # Features
        features = compute_algebraic_features(x, y)
        
        return features, tokens, subtype
    
    def _coeffs_to_tokens(self, coeffs: np.ndarray) -> list[str]:
        """Convert polynomial coefficients to tokens."""
        tokens = []
        for i, c in enumerate(coeffs):
            if abs(c) < 0.01:
                continue
            if tokens:
                tokens.append("ADD" if c > 0 else "SUB")
                c = abs(c)
            
            # Coefficient
            if abs(c - 1.0) > 0.01 or i == 0:
                tokens.extend(self._float_to_tokens(c))
                if i > 0:
                    tokens.append("MUL")
            
            # Variable
            if i == 1:
                tokens.append("X")
            elif i > 1:
                tokens.extend(["X", "POW", str(i)])
        
        return tokens if tokens else ["INT_0"]
    
    def _float_to_tokens(self, v: float) -> list[str]:
        rounded = round(v)
        if abs(v - rounded) < 0.05 and 0 <= rounded <= 10:
            return [f"INT_{int(rounded)}"]
        return ["CONST"] + list(f"{v:.2f}".replace(".", " POINT ").split())


# ============================================================================
# AR Generator
# ============================================================================

class ARGenerator(BaseGenerator):
    SUBTYPES = {
        "ar1_low": {"order": 1, "phi_range": (0.1, 0.4)},
        "ar1_medium": {"order": 1, "phi_range": (0.4, 0.7)},
        "ar1_high": {"order": 1, "phi_range": (0.7, 0.95)},
        "ar2": {"order": 2},
        "ar3": {"order": 3},
    }
    WEIGHTS = {"ar1_low": 1, "ar1_medium": 2, "ar1_high": 2, "ar2": 1, "ar3": 0.5}
    
    def __init__(self, n_steps: int = 200):
        self.n_steps = n_steps
    
    def generate(self) -> tuple[np.ndarray, list[str], str]:
        subtype = self._sample_subtype()
        config = self.SUBTYPES[subtype]
        order = config["order"]
        
        # Generate AR coefficients
        if order == 1:
            phi_range = config.get("phi_range", (0.1, 0.95))
            phi = [np.random.uniform(*phi_range)]
        else:
            # Stable AR(p) - simple approach
            phi = np.random.uniform(-0.4, 0.4, size=order)
            phi[0] = np.random.uniform(0.3, 0.8)  # dominant lag-1
        
        # Generate series
        y = np.zeros(self.n_steps, dtype=np.float32)
        for t in range(order, self.n_steps):
            y[t] = sum(phi[i] * y[t - i - 1] for i in range(order))
            y[t] += np.random.normal(0, 0.1)
        
        # Tokens
        tokens = ["X"]
        for i, p in enumerate(phi):
            tokens.extend(["MUL", "CONST"] + list(f"{p:.2f}".replace(".", " POINT ").split()))
        
        features = compute_timeseries_features(y)
        return features, tokens, subtype


# ============================================================================
# Transcendental Generator
# ============================================================================

class TranscendentalGenerator(BaseGenerator):
    SUBTYPES = {
        "exp_growth": {"form": "exp", "b_sign": 1},
        "exp_decay": {"form": "exp", "b_sign": -1},
        "power_positive": {"form": "power", "b_range": (0.5, 3)},
        "power_negative": {"form": "power", "b_range": (-3, -0.5)},
        "logarithmic": {"form": "log"},
        "logistic": {"form": "logistic"},
    }
    WEIGHTS = {k: 1.0 for k in SUBTYPES}
    
    def __init__(self, n_points: int = 200, x_range: tuple = (0.1, 10)):
        self.n_points = n_points
        self.x_range = x_range
    
    def generate(self) -> tuple[np.ndarray, list[str], str]:
        subtype = self._sample_subtype()
        config = self.SUBTYPES[subtype]
        form = config["form"]
        
        x = np.linspace(*self.x_range, self.n_points)
        
        if form == "exp":
            a = np.random.uniform(0.5, 2)
            b = np.random.uniform(0.1, 0.5) * config["b_sign"]
            y = a * np.exp(b * x)
            tokens = self._float_to_tokens(a) + ["MUL", "EXP"] + self._float_to_tokens(b) + ["MUL", "X"]
        
        elif form == "power":
            a = np.random.uniform(0.5, 2)
            b = np.random.uniform(*config["b_range"])
            y = a * np.power(x, b)
            tokens = self._float_to_tokens(a) + ["MUL", "X", "POW"] + self._float_to_tokens(b)
        
        elif form == "log":
            a = np.random.uniform(0.5, 3)
            b = np.random.uniform(-2, 2)
            y = a * np.log(x) + b
            tokens = self._float_to_tokens(a) + ["MUL", "LN", "X", "ADD"] + self._float_to_tokens(b)
        
        elif form == "logistic":
            L = np.random.uniform(1, 10)
            k = np.random.uniform(0.5, 2)
            x0 = np.random.uniform(3, 7)
            y = L / (1 + np.exp(-k * (x - x0)))
            tokens = self._float_to_tokens(L) + ["DIV", "INT_1", "ADD", "EXP", "NEG"] + \
                     self._float_to_tokens(k) + ["MUL", "X", "SUB"] + self._float_to_tokens(x0)
        
        features = compute_algebraic_features(x, y)
        return features, tokens, subtype
    
    def _float_to_tokens(self, v: float) -> list[str]:
        rounded = round(v)
        if abs(v - rounded) < 0.05 and 0 <= rounded <= 10:
            return [f"INT_{int(rounded)}"]
        return ["CONST"] + list(f"{v:.2f}".replace(".", " POINT ").split())


# ============================================================================
# Physics Laws Generator
# ============================================================================

class PhysicsLawsGenerator(BaseGenerator):
    SUBTYPES = {
        "newton_gravity": {"law": "inverse_square", "vars": ["M1", "M2", "R"]},
        "coulomb": {"law": "inverse_square", "vars": ["Q1", "Q2", "R"]},
        "ideal_gas": {"law": "ideal_gas", "vars": ["N_MOLES", "T", "V"]},
        "kinetic_energy": {"law": "kinetic", "vars": ["M", "V"]},
        "hookes_law": {"law": "linear", "vars": ["K", "X"]},
    }
    WEIGHTS = {k: 1.0 for k in SUBTYPES}
    
    def __init__(self, n_samples: int = 100):
        self.n_samples = n_samples
    
    def generate(self) -> tuple[np.ndarray, list[str], str]:
        subtype = self._sample_subtype()
        config = self.SUBTYPES[subtype]
        law = config["law"]
        var_names = config["vars"]
        
        # Generate input data
        data = {}
        for var in var_names:
            if var == "R":
                data[var] = np.random.uniform(1, 10, self.n_samples)
            elif var in ("M", "M1", "M2"):
                data[var] = np.random.uniform(1, 100, self.n_samples)
            elif var in ("Q1", "Q2"):
                data[var] = np.random.uniform(-10, 10, self.n_samples)
            elif var == "V":
                data[var] = np.random.uniform(0.1, 10, self.n_samples)
            elif var == "T":
                data[var] = np.random.uniform(200, 400, self.n_samples)
            elif var == "N_MOLES":
                data[var] = np.random.uniform(0.1, 5, self.n_samples)
            elif var == "K":
                data[var] = np.random.uniform(1, 100, self.n_samples)
            elif var == "X":
                data[var] = np.random.uniform(-1, 1, self.n_samples)
        
        # Compute output
        if law == "inverse_square":
            C = np.random.uniform(0.1, 10)
            output = C * data[var_names[0]] * data[var_names[1]] / (data["R"] ** 2)
            tokens = ["C", "MUL", var_names[0], "MUL", var_names[1], "DIV", "R", "POW", "INT_2"]
        
        elif law == "ideal_gas":
            C = 8.314  # R_GAS
            output = data["N_MOLES"] * C * data["T"] / data["V"]
            tokens = ["N_MOLES", "MUL", "C", "MUL", "X", "DIV", "V"]  # X = T
        
        elif law == "kinetic":
            output = 0.5 * data["M"] * data["V"] ** 2
            tokens = ["HALF", "MUL", "M", "MUL", "V", "POW", "INT_2"]
        
        elif law == "linear":
            output = data["K"] * data["X"]
            tokens = ["K", "MUL", "X"]
        
        data["output"] = output
        features = compute_physics_features(data)
        
        return features, tokens, subtype


# ============================================================================
# Generator Registry
# ============================================================================

GENERATORS = {
    "polynomial": PolynomialGenerator,
    "ar": ARGenerator,
    "transcendental": TranscendentalGenerator,
    "physics_laws": PhysicsLawsGenerator,
}

def get_generator(model_type: str, **kwargs):
    if model_type not in GENERATORS:
        raise ValueError(f"Unknown model type: {model_type}")
    return GENERATORS[model_type](**kwargs)
