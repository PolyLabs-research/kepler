#!/usr/bin/env python3
"""
train.py - Unified training script (NVIDIA/CPU agnostic)

Usage:
    python train.py --model polynomial
    python train.py --model ar --steps 10000
    python train.py --model polynomial --resume
"""
import argparse
import signal
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn

from config import get_device, auto_batch_size, CONFIGS, TRAINING, DOMAINS
from vocab import Vocabulary
from model import SymbolicTransformer
from generators import get_generator


class OnlineDataset(torch.utils.data.IterableDataset):
    """Generate samples on-the-fly (no pre-compilation needed)."""
    
    def __init__(self, generator, vocab, max_seq_len: int):
        self.generator = generator
        self.vocab = vocab
        self.max_seq_len = max_seq_len
    
    def __iter__(self):
        while True:
            features, tokens, _ = self.generator.generate()
            
            # Encode tokens
            target_ids = [self.vocab.bos_token] + self.vocab.encode(tokens) + [self.vocab.eos_token]
            target_ids = target_ids[:self.max_seq_len]
            target_ids += [self.vocab.pad_token] * (self.max_seq_len - len(target_ids))
            
            yield (
                torch.tensor(features, dtype=torch.float32),
                torch.tensor(target_ids, dtype=torch.long),
            )


def get_lr(step: int, warmup: int, base_lr: float) -> float:
    """Linear warmup then constant."""
    if step < warmup:
        return base_lr * step / warmup
    return base_lr


def train(args):
    device = get_device()
    print(f"Device: {device}", flush=True)
    
    # Config
    if args.model not in CONFIGS:
        print(f"Unknown model: {args.model}. Available: {list(CONFIGS.keys())}")
        sys.exit(1)
    
    cfg = CONFIGS[args.model]
    domain = DOMAINS[args.model]
    
    # Auto-scale batch size
    batch_size = args.batch_size or auto_batch_size(512)
    print(f"Batch size: {batch_size}", flush=True)
    
    # Paths
    checkpoint_dir = Path("checkpoints") / domain / args.model
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    
    # Vocab & Generator
    vocab = Vocabulary.default()
    generator = get_generator(args.model)
    
    # Model
    model = SymbolicTransformer(
        vocab_size=vocab.vocab_size,
        **cfg
    ).to(device)
    
    param_count = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {param_count:,}", flush=True)
    
    # Optimizer
    optimizer = torch.optim.AdamW(model.parameters(), lr=TRAINING["learning_rate"])
    criterion = nn.CrossEntropyLoss(ignore_index=vocab.pad_token)
    
    # Resume
    start_step = 0
    best_loss = float("inf")
    
    best_path = checkpoint_dir / "model_best.pt"
    if args.resume and best_path.exists():
        ckpt = torch.load(best_path, map_location=device, weights_only=False)
        model.load_state_dict(ckpt["model"])
        optimizer.load_state_dict(ckpt["optimizer"])
        start_step = ckpt.get("step", 0)
        best_loss = ckpt.get("loss", float("inf"))
        print(f"Resumed from step {start_step}, loss={best_loss:.4f}", flush=True)
    
    # Dataset
    dataset = OnlineDataset(generator, vocab, cfg["max_seq_len"])
    loader = torch.utils.data.DataLoader(
        dataset,
        batch_size=batch_size,
        num_workers=0,  # Safe for all platforms
        pin_memory=(device == "cuda"),
    )
    
    # Training state
    running_loss = 0.0
    step = start_step
    max_steps = args.steps or TRAINING["max_steps"]
    interrupted = False
    
    def handle_interrupt(sig, frame):
        nonlocal interrupted
        print("\n[!] Interrupt detected. Saving...", flush=True)
        interrupted = True
    
    signal.signal(signal.SIGINT, handle_interrupt)
    
    # Training loop
    model.train()
    data_iter = iter(loader)
    
    while step < max_steps and not interrupted:
        try:
            features, targets = next(data_iter)
        except StopIteration:
            data_iter = iter(loader)
            features, targets = next(data_iter)
        
        features = features.to(device)
        targets = targets.to(device)
        
        # LR schedule
        lr = get_lr(step, TRAINING["warmup_steps"], TRAINING["learning_rate"])
        for pg in optimizer.param_groups:
            pg["lr"] = lr
        
        # Forward
        tgt_input = targets[:, :-1]
        tgt_output = targets[:, 1:]
        
        logits = model(features, tgt_input)
        loss = criterion(logits.reshape(-1, vocab.vocab_size), tgt_output.reshape(-1))
        
        # Backward
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), TRAINING["gradient_clip"])
        optimizer.step()
        
        # Logging
        running_loss += loss.item()
        step += 1
        
        if step % TRAINING["log_interval"] == 0:
            avg_loss = running_loss / TRAINING["log_interval"]
            print(f"[{step}/{max_steps}] loss={loss.item():.4f} avg={avg_loss:.4f} lr={lr:.2e}", flush=True)
            
            if avg_loss < best_loss:
                best_loss = avg_loss
                torch.save({
                    "model": model.state_dict(),
                    "optimizer": optimizer.state_dict(),
                    "step": step,
                    "loss": best_loss,
                }, best_path)
                print(f"Saved BEST checkpoint (loss={best_loss:.4f})", flush=True)
            
            running_loss = 0.0
    
    # Final save
    final_path = checkpoint_dir / "model_interrupted.pt" if interrupted else checkpoint_dir / "model_final.pt"
    torch.save({
        "model": model.state_dict(),
        "optimizer": optimizer.state_dict(),
        "step": step,
        "loss": best_loss,
    }, final_path)
    print(f"Saved to {final_path}", flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=str, required=True, help="Model type")
    parser.add_argument("--steps", type=int, default=None, help="Max training steps")
    parser.add_argument("--batch-size", type=int, default=None, help="Override batch size")
    parser.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    
    args = parser.parse_args()
    train(args)
